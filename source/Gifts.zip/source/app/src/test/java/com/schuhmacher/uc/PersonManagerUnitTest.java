package com.schuhmacher.uc;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class PersonManagerUnitTest {
    @Test
    public void insertPerson() {
        System.out.println("Todo : apprendre a tester l'appli sans la base de données, puis les DAO");
        assertEquals(5, 2 + 3);
    }
}
