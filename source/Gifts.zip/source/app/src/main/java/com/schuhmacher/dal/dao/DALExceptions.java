package com.schuhmacher.dal.dao;

public class DALExceptions {
}
