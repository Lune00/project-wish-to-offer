package com.schuhmacher.uc;

public final class PersonManager {

}
