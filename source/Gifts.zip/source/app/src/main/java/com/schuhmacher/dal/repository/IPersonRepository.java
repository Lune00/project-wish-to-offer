package com.schuhmacher.dal.repository;


import com.schuhmacher.room.room.entities.PersonEntity;

public interface IPersonRepository {

    void insert(PersonEntity person);

}
