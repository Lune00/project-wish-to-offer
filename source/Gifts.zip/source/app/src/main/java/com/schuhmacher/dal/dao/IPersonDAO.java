package com.schuhmacher.dal.dao;

import com.schuhmacher.room.room.entities.PersonEntity;

public interface IPersonDAO {

    long insert(PersonEntity personEntity);

}
